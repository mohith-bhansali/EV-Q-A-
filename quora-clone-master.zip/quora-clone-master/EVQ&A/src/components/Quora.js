  
import React from "react";


import "../css/Quora.css";
import Feed from "./Feed";
import Navbar from "./Navbar";
import SideBar from "./SideBar";





function Quora() {
  return (
    <div className="quora">
      
     <Navbar/>
     <div className="quora__content">
       <SideBar/>
       <Feed/>

     </div>
     
    </div>
  );
}

export default Quora;