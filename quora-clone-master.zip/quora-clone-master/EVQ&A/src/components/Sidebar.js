import React from "react";

import '../css/SideBar.css';
import SidebarOption from "./SideBaroption";

function SideBar() {
  return (
    <div className="sidebar">
      <SidebarOption/>
    </div>
  );
}

export default SideBar;