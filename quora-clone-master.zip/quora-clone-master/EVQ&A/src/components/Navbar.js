import React from "react";
import HomeIcon from "@material-ui/icons/Home"  
import  FeaturedPlayListOutlinedIcon    from "@material-ui/icons/FeaturedPlayListOutlined";
import AssignmentTurnedInOutlinedIcon from "@material-ui/icons/AssignmentTurnedInOutlined";
import PeopleOutlinedIcon from "@material-ui/icons/PeopleOutlined";
import  NotificationsOutlinedIcon  from "@material-ui/icons/NotificationsOutlined";
import  SearchIcon from "@material-ui/icons/Search";
import  { Avatar } from "@material-ui/core";
import { Button } from "@material-ui/core";
import "../css/Navbar.css";

function Navbar() {
  return (
    <div className="qHeader">
        <div className="qHeader_icons">
            <div className="qHeader__icon">
                <HomeIcon/>
            </div>
            <div className="qHeader__icon">
                <FeaturedPlayListOutlinedIcon/>
            </div>
            <div className="qHeader__icon">
                <AssignmentTurnedInOutlinedIcon/>
            </div>
            <div className="qHeader__icon">
                <PeopleOutlinedIcon/>
            </div>
            <div className="qHeader__icon">
                <NotificationsOutlinedIcon/>
            </div>
            <div className="qHeader__input">
                <SearchIcon/>
                <input type="text" placeholder="Search"/>
            </div>
            <div className="qHeader__Rem">
                <div className="qHeader__avatar">
                    <Avatar/>
                </div>
                <Button>Add Question</Button>
            </div>
        </div>
    </div> 
  );
}


export default Navbar;
